function setup() { 
  createCanvas(400, 400);
}

function draw() {
  background("blue");
  arc(150, 200, 60, 10, 200, 360);
  fill ("green");
  stroke("black");
  strokeWeight(4);
ellipse(170,200,40, 80, );
  
}